#!/usr/bin/env python3
"""
Excel拆分示例脚本
将大Excel文件按5万行拆分为多个文件
"""

import pandas as pd
import os
from datetime import datetime

def split_excel_file(input_file, output_dir, chunk_size=50000):
    """
    拆分Excel文件
    
    Args:
        input_file: 输入Excel文件路径
        output_dir: 输出目录
        chunk_size: 每个文件的行数（默认5万）
    """
    print(f"📂 读取文件: {input_file}")
    
    try:
        # 读取Excel文件
        df = pd.read_excel(input_file)
        total_rows = len(df)
        
        print(f"📊 数据统计: {total_rows:,} 行, {len(df.columns)} 列")
        print(f"📋 列名: {', '.join(df.columns.tolist())}")
        
        # 计算需要拆分的文件数量
        num_chunks = (total_rows + chunk_size - 1) // chunk_size
        print(f"🔨 需要拆分为 {num_chunks} 个文件（每个最多 {chunk_size:,} 行）")
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 拆分文件
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_list = []
        
        for i in range(num_chunks):
            start_idx = i * chunk_size
            end_idx = min((i + 1) * chunk_size, total_rows)
            
            chunk_df = df.iloc[start_idx:end_idx]
            chunk_rows = len(chunk_df)
            
            # 生成文件名
            output_file = os.path.join(
                output_dir, 
                f'pdd_batch_{timestamp}_part{i+1:03d}_of_{num_chunks}.xlsx'
            )
            
            # 保存文件
            chunk_df.to_excel(output_file, index=False)
            file_list.append((output_file, chunk_rows))
            
            print(f"  ✅ 文件 {i+1}/{num_chunks}: {os.path.basename(output_file)} ({chunk_rows:,} 行)")
        
        # 生成报告
        print(f"\n📊 拆分完成!")
        print(f"原始文件: {input_file}")
        print(f"总行数: {total_rows:,}")
        print(f"拆分文件数: {len(file_list)}")
        print(f"输出目录: {output_dir}")
        
        return True
        
    except Exception as e:
        print(f"❌ 处理失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    # 示例用法
    print("🛠️ Excel拆分工具 - 示例")
    print("="*50)
    
    # 创建测试数据
    test_data = []
    for i in range(1, 120001):  # 12万行测试数据
        test_data.append({
            '当当ID': f'DD{i:06d}',
            '拼多多SPUID': f'P{i:06d}',
            '拼多多ID': f'S{i:06d}',
            '价格': round(50 + (i % 100) * 0.5, 2),
            '商品名称': f'测试商品{i:06d}'
        })
    
    df = pd.DataFrame(test_data)
    
    # 保存测试文件
    test_dir = os.path.join(os.path.dirname(__file__), "../data")
    os.makedirs(test_dir, exist_ok=True)
    
    test_file = os.path.join(test_dir, "test_data_120k.xlsx")
    df.to_excel(test_file, index=False)
    
    print(f"📝 创建测试文件: {test_file} ({len(df):,} 行)")
    
    # 拆分测试文件
    output_dir = os.path.join(test_dir, "split_files")
    split_excel_file(test_file, output_dir, chunk_size=50000)
    
    print("\n🎯 下一步:")
    print("1. 使用真实数据替换测试数据")
    print("2. 开发拼多多登录模块")
    print("3. 实现批量上传功能")
