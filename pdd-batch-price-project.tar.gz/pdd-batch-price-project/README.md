# 拼多多批量改价项目

## 项目概述
自动化处理拼多多批量改价任务，支持60万行Excel数据拆分和批量上传。

## 功能特性
1. Excel文件拆分（每5万行一个文件）
2. 拼多多后台自动登录
3. 批量文件上传和改价
4. 错误恢复和进度跟踪

## 已安装技能
- agent-browser: 浏览器自动化
- excel-parser-skill: Excel解析
- excel-xlsx: Excel编辑
- batch-processing-patterns: 批量处理
- pinduoduo-automation: 拼多多自动化参考

## 快速开始
1. 验证安装: `python3 verify_installation.py`
2. 测试Excel拆分: 参考原型代码
3. 开发拼多多登录模块

## 项目结构
```
pdd-batch-price-project/
├── README.md              # 项目文档
├── verify_installation.py # 验证脚本
├── scripts/              # 开发脚本目录
└── data/                # 测试数据目录
```

## 技术支持
- 技能问题: 查看各技能的SKILL.md文件
- Python问题: 检查依赖安装
- 项目问题: 参考原型代码
