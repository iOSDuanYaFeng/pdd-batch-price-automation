#!/usr/bin/env python3
"""
验证拼多多项目安装状态
"""

import os
import sys
from pathlib import Path

def main():
    print("🔍 拼多多批量改价项目 - 安装验证")
    print("="*60)
    
    # 检查技能目录
    skills_dir = Path.home() / ".openclaw" / "workspace" / "skills"
    
    required_skills = [
        "agent-browser",
        "excel-parser-skill", 
        "excel-xlsx",
        "batch-processing-patterns",
        "pinduoduo-automation"
    ]
    
    print("📋 核心技能检查:")
    print("-"*40)
    
    all_installed = True
    for skill in required_skills:
        skill_path = skills_dir / skill
        if skill_path.exists():
            print(f"✅ {skill:25} 已安装")
        else:
            print(f"❌ {skill:25} 未安装")
            all_installed = False
    
    print("\n📋 Python依赖检查:")
    print("-"*40)
    
    required_packages = ["pandas", "openpyxl", "selenium", "playwright"]
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package:25} 已安装")
        except ImportError:
            print(f"❌ {package:25} 未安装")
            all_installed = False
    
    print("\n" + "="*60)
    if all_installed:
        print("🎉 所有依赖已安装完成！")
        print("可以开始拼多多批量改价项目开发。")
        return 0
    else:
        print("⚠️  部分依赖未安装。")
        print("请重新运行安装脚本或手动安装缺失的组件。")
        return 1

if __name__ == "__main__":
    sys.exit(main())
